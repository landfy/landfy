# [Start Bootstrap - New Age](https://startbootstrap.com/template-overviews/new-age/)

[New Age](http://startbootstrap.com/template-overviews/new-age/) is a web app landing page theme for [Bootstrap](http://getbootstrap.com/) created by [Start Bootstrap](http://startbootstrap.com/).

## Preview

[![New Age Preview](https://startbootstrap.com/assets/img/templates/new-age.jpg)](https://blackrockdigital.github.io/startbootstrap-new-age/)

**[View Live Preview](https://blackrockdigital.github.io/startbootstrap-new-age/)**

## Original sources

https://github.com/BlackrockDigital/startbootstrap-new-age

## Copyright and License
 
[MIT](https://github.com/BlackrockDigital/startbootstrap-new-age/blob/gh-pages/LICENSE)
